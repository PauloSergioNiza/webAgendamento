$(document).ready(function () {
    $("body").on('click', '#btnInserir', function () {
        var dados = $('#forminserir').serialize();
        console.log(dados);
        $.post('../php/acoes.php', dados+'&acao=inserir', function (ret) {
            console.log(ret);
        });
    });
    $("body").on('click', '#excluir', function () {
        var id = $(this).attr("rel");
        console.log(id);
        $('#dado'+id).fadeOut(300);
        $.post('../php/acoes.php','id='+id+'&acao=excluir', function (ret) {

            console.log(ret);
        });
    });
    $("body").on('click', '#editar', function () {
        var id = $(this).attr("rel");
        window.location.href = '../htmls/editar.php?id='+id;
    });
    $("body").on('click', '#btnatualizar', function () {
        var id = $(this).attr("rel");
        var dados = $('#forminseriratt').serialize();
        console.log(id);
        $.post('../php/acoes.php',dados+'&id='+id+'&acao=editar', function (ret) {
            console.log(ret);
            window.location.href = '../htmls/buscar.php';
        });
    });
});