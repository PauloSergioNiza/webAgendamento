<? php
require_once ( "Banco.php" );

classe  Cadastro  extends  Banco {

    private  $ nome ;
    private  $ telefone ;
    private  $ origem ;
    private  $ data_contato ;
    private  $ Observação ;

    
    public  function  setNome ( $ string ) {
        $ this -> nome = $ string ;
    }
    public  function  setTelefone ( $ string ) {
        $ this -> telefone = $ string ;
    }
    public  function  setOrigem ( $ string ) {
        $ this -> origem = $ string ;
    }
    public  function  setData_contato ( $ string ) {
        $ this -> data_contato = $ string ;
    }
    public  function  setObservacao ( $ string ) {
        $ this -> observacao = $ string ;
    }

    
    public  function  getNome () {
        return  $ this -> nome ;
    }
    public  function  getTelefone () {
        retornar  $ este -> telefone ;
    }
    public  function  getOrigem () {
        return  $ this -> origem ;
    }
    public  function  getData_contato () {
        return  $ this -> data_contato ;
    }
    public  function  getObservacao () {
        return  $ this -> observacao ;
    }

    public  function  incluir () {
        return  $ this -> setAgendar ( $ this -> getNome (), $ this -> getTelefone (), $ this -> getOrigem (), $ this -> getData_contato (), $ this -> getObservacao ());
    }
}
?>