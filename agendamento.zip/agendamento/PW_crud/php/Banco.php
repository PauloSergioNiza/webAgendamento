<? php


date_default_timezone_set ( 'America / Sao_Paulo' );



define ( 'BD_SERVIDOR' , 'localhost' );
define ( 'BD_USUARIO' , 'root' );
define ( 'BD_SENHA' , '' );
define ( 'BD_BANCO' , 'webagendamentos' );
    
classe Banco {

    protegido  $ mysqli ;

    public  function  __construct () {
        $ this -> conexao ();
    }

     função  privada conexao () {
        $ this -> mysqli = novo mysqli ( BD_SERVIDOR , BD_USUARIO , BD_SENHA , BD_BANCO );
    }

    public  function  setAgendar ( $ nome , $ telefone , $ origem , $ data_contato , $ observacao ) {
        $ stmt = $ this -> mysqli -> prepare ( "INSERT INTO agendar (` nome`, `telefone`,` origem`, `data_contato`,` observacao`) VALORES (?,?,?,?,?) " );
        $ stmt -> bind_param ( "sssss" , $ nome , $ telefone , $ origem , $ data_contato , $ observacao );
        if ( $ stmt -> execute () == TRUE ) {
            return  true ;
        } else {
            return  false ;
        }

    }
}    
?>