<? php
require_once ( "/agendamento/PW_crud/php/cadastro2.php" );
class cadastroController {

     $ cadastro privado ;

    public  function  __construct () {
        $ this -> cadastro = novo  Cadastro ();
        $ this -> incluir ();
    }

     função  privada incluir () {
        $ this -> cadastro -> setNome ( $ _POST [ 'txtNome' ]);
        $ this -> cadastro -> setTelefone ( $ _POST [ 'txtTelefone' ]);
        $ this -> cadastro -> setOrigem ( $ _POST [ 'txtOrigem' ]);
        $ this -> cadastro -> setData_contato ( date ( 'Ym-d' , strtotime ( $ _POST [ 'txtDataContato' ])));
        $ this -> cadastro -> setObservacao ( $ _POST [ 'txtObservacao' ]);
        $ result = $ this -> cadastro -> incluir ();
        if ( $ resultado > = 1 ) {
            echo  "<script> alert ('Registro incluído com sucesso!'); document.location = '.. / cadastro.php' </script>" ;
        } else {
            echo  "<script> alert ('Erro ao gravar registro!'); </script>" ;
        }
    }
}
novo cadastroController ();